/**
 * Created by SarahShank on 12/5/14.
 */
/* Sarah Shank
12/5/2014
Duel fight game
Assignment 2 Week 2
 */
//
//self- executing function
(function(){

    console.log ("FIGHT!!!"); // printing to browser console the word FIGHT!!!
                                //program starts
								
    var player1= ["Spiderman", 20, 100]; // variable player1 set up array for name, damage , and health*
	var player2= ["Batman", 20, 100];   //variable player2 set up array for name, damage, and health*

 /*//player names
    var playerOneName = "Spiderman"; //variable name of player 1
    var playerTwoName = "Batman";    //variable name of player 2

//player damage
    var player1Damage = 20; //variable for damage taken from player 1
    var player2Damage = 20; //variable for damage taken from player 2

//player health
    var playerOneHealth = 100; // variable of players health status for player 1
    var playerTwoHealth = 100; // variable of players health status for player 2
*/
    var round = 0; //variable for fight round number

   

    function fight(){ // clicking the OK button will run a loop repeating the game through each round


        console.log("in the fight function");// printing in the fight function to the browser console
    // alert that pops up to inform the player about the players name, health and the *START* title *
         alert(player1[0]+":"+player1[2]+"  *START*  "+player2[0]+":"+player2[2]);
      

        // having the game loop through up to ten rounds unless there is a winner or loser declared
        for(var i=0;i < 10;i++){
            //code will go here
            //console.log(i);
            //random formula is - Math.floor(Math.random() * (max - min) + min);
			//define variables for players using array index *
   			 var minDamage1 = player1[1] * .5;
        //variable using a random math formula to predict the player outcome
		//define variables for players using array index *
			 var minDamage2 = player2[1] * .5;
        //array using a random math formula to predict the player outcome *
            var f1= Math.floor(Math.random()*(player1[1]-minDamage1)+minDamage1); 				         //random generator code
            var f2= Math.floor(Math.random()*(player2[1]-minDamage2)+minDamage2); 
            //console.log(f1);
            //console.log(f2);

            //inflict damage on players during the rounds in the game
			//array used to inflict damage deductions *
			 player1[2]-=f1;  // player one deducting
             //array used to inflict damage deductions *
             player2[2]-=f2;  // player two deductin

            //console.log(player1 health using array index);
            //console.log(player2 health using array index);
            //printing the players results to the browser console.
            console.log(player1[0]+":"+player1[2]+""+player2[0]+":"+player2[2]);
            //variable for checking the players results as to who won the game

            var results = winnerCheck(); // variable result equals winnerCheck
            console.log(results); // printing to browser the results

            //telling the computer that if there is no winner to print on the browser

            if(results ==="no winner"){ // if results are exactly equal to no winner
                round++; // adding plus 1 to each round
                //pop up alerts player about players status of names, health, and round number using array index *
                alert(player1[0]+":"+player1[2]+" *ROUND "+round+" OVER*"+player2[0]+":"+player2[2]);

            }else { // if there is a winner stop the rounds and alert the players results of the game
                alert(results);
                break; //stopping the games rounds
            };

        };

    };

    function winnerCheck(){ // declaring the winners results
        //code will go here
        console.log("in winnerCheck FN");// displaying on the browser the players game results
		//using array index to return players winning/losing results *
        var result="no winner"; //variable for results for no winner
 		if (player1[2]<1 && player2[2]<1){ // stating that is player 1 & 2 both have <1 than both die
          
		  result= "You Both Die"; // result equals you both die
        }else if(player1[2]<1){ // if player 1 health is <1
            result= player2[0]+" WINS!!!" //the result of player 2 will show  player 2 WINS!! 
        }else if(player2[2]<1){ // if player 2 health is <1 than result will show
            result= player1[0]+" WINS!!!" // result shows player 1 will show  player 1 WINS!!

        };
       return result;

    };

    /**The program gets started below**/
    console.log("program starts");
    fight();

})();
